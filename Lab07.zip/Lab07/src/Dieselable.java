public interface Dieselable {
    public abstract void startEngine();
    public abstract void stopEngine();
    
}
