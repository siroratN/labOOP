public interface Flyable {
    public abstract void fly();
    public abstract void takeOff();
    public abstract void landing();
}
