/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Sirorat
 */
public class Meat extends Food{
    public Meat(){
        super();
    }
    @Override
    public int getPower(){
        return 50;
    }
}
